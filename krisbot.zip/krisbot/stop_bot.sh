stop_bot.sh

#!/bin/bash
cd "$(dirname "$0")"
echo "🛑 Остановка Telegram бота..."
pm2 stop telegram-bot
echo "✅ Бот остановлен"