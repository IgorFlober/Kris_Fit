restart_bot.sh

#!/bin/bash
cd "$(dirname "$0")"
echo "🔄 Перезапуск Telegram бота..."
pm2 restart telegram-bot
echo "✅ Бот перезапущен"