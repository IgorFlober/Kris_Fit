status_bot.sh

#!/bin/bash
cd "$(dirname "$0")"
echo "📊 Статус Telegram бота:"
pm2 status telegram-bot