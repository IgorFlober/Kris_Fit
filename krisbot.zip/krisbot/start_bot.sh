start_bot.sh

#!/bin/bash
cd "$(dirname "$0")"
echo "🚀 Запуск Telegram бота..."
mkdir -p logs
pm2 start ecosystem.config.js
pm2 save
echo "✅ Бот запущен!"
echo "📊 Проверить статус: pm2 status"
echo "📝 Посмотреть логи: pm2 logs telegram-bot"